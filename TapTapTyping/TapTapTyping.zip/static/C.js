const C=[
    "C.C ..C CC. C.C ..C CC. C.C ..C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. C.C ..C CC. C.C ..C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. ..C C.C",
    "C.C ..C CC. C.C ..C CC. C.C ..C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. C.C ..C CC. C.C ..C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. ..C C.C",
    "C.C ..C CC. C.C ..C CC. C.C ..C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. C.C ..C CC. C.C ..C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. ..C C.C",
    "C.C ..C CC. C.C ..C CC. C.C ..C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. C.C ..C CC. C.C ..C CC. ..C C.C CC. ..C C.C CC. ..C C.C CC. ..C C.C"
]