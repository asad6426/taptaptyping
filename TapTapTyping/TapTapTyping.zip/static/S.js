const S=[
    "S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS;",
    ";;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS;",
    "S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS;",
    "S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS; S;S ;;S S;S S;; SS;"
]