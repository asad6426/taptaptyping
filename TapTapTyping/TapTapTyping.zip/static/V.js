const V=[
    "V,V ,,V VV, V,V ,,V VV, V,V ,,V V,V ,,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, V,V ,,V VV, V,V ,,V VV, ,,V V,V VV, ,,V V,V VV,",
    "V,V ,,V VV, V,V ,,V VV, V,V ,,V V,V ,,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, V,V ,,V VV, V,V ,,V VV, ,,V V,V VV, ,,V V,V VV,",
    "V,V ,,V VV, V,V ,,V VV, V,V ,,V V,V ,,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, V,V ,,V VV, V,V ,,V VV, ,,V V,V VV, ,,V V,V VV,",
    "V,V ,,V VV, V,V ,,V VV, V,V ,,V V,V ,,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, ,,V V,V VV, V,V ,,V VV, V,V ,,V VV, ,,V V,V VV, ,,V V,V VV,"
]