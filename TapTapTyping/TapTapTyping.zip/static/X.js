const X=[
    "X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX",
    ",XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX",
    "XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX",
    "X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX, X,X ,XX XX, X,X X,, XX, X,X ,XX X,X XX, X,, XX"
]