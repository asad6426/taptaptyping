const Z=[
    "Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ",
    ".ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ",
    "ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ.",
    "Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.. ZZ. Z.Z .ZZ ZZ. Z.Z Z.. ZZ. Z.Z .ZZ Z.Z ZZ. Z.."
]