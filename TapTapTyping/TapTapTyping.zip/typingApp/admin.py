from django.contrib import admin

from typingApp.models import JobPost,BlogPost

# Register your models here.
admin.site.register(JobPost)
admin.site.register(BlogPost)